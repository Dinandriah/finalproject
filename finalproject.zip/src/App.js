import React, { Component } from 'react';
import './App.css';
import Homepage from './pages/home'
class App extends Component {
  render() {
    return (
      <Homepage></Homepage>
        
    );
  }
}

export default App;
